import React from 'react';

const Ads: React.FC = () => {
  return (
    <div className="bg-gray-100 rounded-lg p-4 text-center text-sm text-gray-600 mt-0 h-[360px]">
      광고 자리 (이미지 배너 예정)
    </div>
  );
};

export default Ads;