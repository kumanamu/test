package com.we.hirehub.repository;

import com.we.hirehub.entity.Ads;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdsRepository extends JpaRepository<Ads, Long> {
}
