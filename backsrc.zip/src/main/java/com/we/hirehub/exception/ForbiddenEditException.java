package com.we.hirehub.exception;

public class ForbiddenEditException extends RuntimeException {
    public ForbiddenEditException(String m) { super(m); }
}
