package com.we.hirehub.service;

import com.we.hirehub.dto.UsersDto;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    public void register(UsersDto dto){
        // TODO: map to com.we.hirehub.entity.Users and save via repository
    }
}
